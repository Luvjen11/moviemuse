package com.example.moviemuse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoviemuseApplicationTests {

	@Test
	void contextLoads() {
	}

}
